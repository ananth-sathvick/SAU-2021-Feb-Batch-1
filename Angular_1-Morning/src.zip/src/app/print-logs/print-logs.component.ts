import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-logs',
  templateUrl: './print-logs.component.html',
  styleUrls: ['./print-logs.component.scss']
})
export class PrintLogsComponent implements OnInit {

  @Input('logs') logs : any ;
  constructor() { 
  }

  ngOnInit(): void {
  }

}
