import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InputTextBoxComponent } from './input-text-box/input-text-box.component';
import { PrintLogsComponent } from './print-logs/print-logs.component';

@NgModule({
  declarations: [
    AppComponent,
    InputTextBoxComponent,
    PrintLogsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
