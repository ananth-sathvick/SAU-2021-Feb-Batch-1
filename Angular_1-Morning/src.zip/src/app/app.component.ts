import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  logs : Array<any> = [];

  textChanged(text : any)
  {
    // console.log("key up" + text);
    this.logs.push({key_up_at : new Date() ,text : text});
  }
  
}
